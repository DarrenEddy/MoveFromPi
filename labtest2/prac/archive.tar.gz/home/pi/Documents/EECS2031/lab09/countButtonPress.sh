#!/bin/bash
c=0
./setbits.sh 0
while true
do
b=$(gpio read 5) 
if [ $b == 0 ]
then 
let "c=$c+1"
./setbits.sh $c
if [ $c == 16 ]
then 
gpio write 4 1
sleep 1
gpio write 4 0
let "c=0"
fi
while [ $b == 0 ]
do
b=$(gpio read 5)
done
fi
done
