let add=$1$3$2
echo "$add"

