# HouseAlarm
Sample code for lab05
