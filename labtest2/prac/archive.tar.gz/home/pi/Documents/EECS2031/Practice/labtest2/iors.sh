if [ $1 -eq $1 2> /dev/null ]
then
echo "num"
else
echo "not a num"
fi
