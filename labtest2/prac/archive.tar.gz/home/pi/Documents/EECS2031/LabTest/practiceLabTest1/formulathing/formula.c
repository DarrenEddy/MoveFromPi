# include <stdio.h> 
# include "formula.h"

float formula(int x, int n)
{
/*N cannot be negative*/
int i;
int numer =1;
int denom = n;

for (i = 0; i<n; i++)
{
numer = numer * x;
}

if (n!= 0)
{
	for (i=n; i>0; i--)
	{
  	denom = denom * i;
	}
}
else{denom = 1;}

return numer/denom;
}
