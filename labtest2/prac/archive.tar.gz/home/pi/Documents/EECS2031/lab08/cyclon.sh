#!/bin/bash
temp=(8 4 2 1 2 4)
while test true
do
i=0

while test "$i" -lt 6
do
./setbits.sh ${temp[$i]}
let "i=$i+1"
sleep 0.25
done


done




