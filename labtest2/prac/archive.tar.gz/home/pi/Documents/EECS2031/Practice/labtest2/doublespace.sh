sed -e 's/ /  /g' stdin.txt > stdout.txt
