#this is part of the code
cat clone.sh
