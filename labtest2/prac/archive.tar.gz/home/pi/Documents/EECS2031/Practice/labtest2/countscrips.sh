count=$(ls | grep ".sh" | wc -l)
echo $count
