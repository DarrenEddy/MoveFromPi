int quad(int a, int b, int c);
