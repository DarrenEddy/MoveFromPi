#!/bin/bash
i=0
while test $i -lt 16; do
./setbits.sh $i
let "i = $i + 1"
sleep 1
done
./setbits.sh 0




