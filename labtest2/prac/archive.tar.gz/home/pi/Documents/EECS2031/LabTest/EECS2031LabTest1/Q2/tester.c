# include <stdio.h>
# include "q2.h"

int main(int argc, char *argv[])
{
printf("1111 has (%d) 1s\n",countDigits(1111,1));

return 0;
}
