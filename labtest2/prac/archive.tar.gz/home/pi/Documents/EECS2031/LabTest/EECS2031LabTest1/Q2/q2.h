int countDigits(int x, int d);
char testCountDigits(int x, int d, int result, char msg);
