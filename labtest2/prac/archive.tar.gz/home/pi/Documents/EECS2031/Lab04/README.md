# IoT-alarm
eecs2031 IoT alarm assignment. The code here is just the skeleton. You will have to write the rest.
