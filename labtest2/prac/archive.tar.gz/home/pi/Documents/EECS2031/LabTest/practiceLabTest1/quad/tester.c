# include <stdio.h>
# include "quad.h"

int main(int argc, char *argv[])
{
printf("%dx^2+%dx+%d has %d root(s)\n",1,2,3, quad(1,2,3));
printf("%dx^2+%dx+%d has %d root(s)\n",1,0,3, quad(1,0,3));
printf("%dx^2+%dx+%d has %d root(s)\n",-1,2,3, quad(-1,2,3));
return 0;
}
