# include <stdio.h>
# include "isMirrored.h"

int main(int argc, char *argv[])
{
printf("5 is mirrored: %d\n",isMirrored(5));
printf("10 is mirrored: %d\n",isMirrored(10));
printf("17771 is mirrored: %d\n",isMirrored(17771));
printf("2442 is mirrored: %d\n",isMirrored(2442));

return 0;
}
