#include <stdio.h>
#include <wiringPi.h>
#include "ifttt.h"
int main(int argc, char *argv[])
{
  wiringPiSetup () ;
  pinMode(0, INPUT);
  pinMode(1, OUTPUT);
  pinMode(2,OUTPUT);  

while(1) {
/*    printf("Waiting\n");*/
    while(digitalRead(0) == 1){digitalWrite(1,HIGH);}
ifttt("http://red.eecs.yorku.ca:8080/trigger/event/with/key/123", "Enter Name","Alarm Triggered","215019193");   
digitalWrite(1,LOW);   
delay(1000);
    while(digitalRead(0) == 0){digitalWrite(2, HIGH);}
    digitalWrite(2,LOW); 

  }
  /*NOTREACHED*/
  return 0 ;
}
