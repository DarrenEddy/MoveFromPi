# include <stdio.h>
# include "isMirrored.h"
# include <string.h>
# include <stdlib.h>

int main(int argc, char *argv[])
{
char temp[1024];
snprintf(temp, sizeof(temp), "/sys/bus/w1/devices/%s/w1_slave",argv[1]);

printf(temp);
return 1;
}
