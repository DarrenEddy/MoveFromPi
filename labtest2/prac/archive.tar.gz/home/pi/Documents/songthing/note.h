void note(int freq, int duration);
