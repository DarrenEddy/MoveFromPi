#!/bin/bash
i=0
while test $i -lt 5; do

j=0
while test $j -lt 4; do
gpio write $j 1
let "j = $j + 1"
done

sleep 1 

k=0
while test $k -lt 4; do
gpio write $k 0
let "k = $k + 1"
done

sleep 1

let "i = $i + 1"
done




