int isMirrored(int x);
