# include <stdio.h> 
# include "quad.h"

int quad(int a, int b, int c)
{
int desc = 2*a*b;
if (desc == 0){return 1;}
else if (desc < 0){return 0;}
else{return 2;}
}
