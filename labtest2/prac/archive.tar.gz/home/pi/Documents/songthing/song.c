# include <stdio.h>
# include "note.h"
# include <wiringPi.h>
# include <softTone.h>

int main(int argc, char *argv[])
{

wiringPiSetup();
softToneCreate(0);

for(;;){

note(349,4);
note(0,8);
note(330,16);
note(370,4);
note(261,16);
note(220,16);
note(330,5);
note(0, 8);
}
return 1;
}
