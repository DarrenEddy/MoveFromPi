# include <stdio.h> 
# include "note.h"
# include <softTone.h>
# include <wiringPi.h>
# define MOD 4000
# define DEAD 40
# define PITCH_MOD 4
void note(int freq, int duration)
{

softToneWrite(0,freq * PITCH_MOD);
delay((int)(MOD/duration)-DEAD);
softToneWrite(0,0);
delay(DEAD);
}
