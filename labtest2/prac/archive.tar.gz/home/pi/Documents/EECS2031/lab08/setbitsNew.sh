#!/bin/bash
i=0
j=3
temp=$1

while [ "$i" -lt 4 ]
do
if [ $(( temp & 1 )) = 1 ]
then
gpio write $j 1
else 
gpio write $j 0
fi

let "i=$i+1"
let "j=$j-1"
let "temp=$temp>>1"
done
