float formula(int x,int n);
