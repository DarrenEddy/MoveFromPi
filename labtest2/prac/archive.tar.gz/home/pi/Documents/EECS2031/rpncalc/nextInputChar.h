void setFile(FILE *d);
int getChar();
void ungetChar(int ch);
