tar -zcvf archive.tar.gz ~/Documents
