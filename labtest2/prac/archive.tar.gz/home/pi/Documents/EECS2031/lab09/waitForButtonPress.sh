#!/bin/bash
while true
do
b=$(gpio read 5)

if [ $b == 1 ]
then 
echo "Waiting"

elif [ $b == 0 ]
then 
echo "CLICK"
sleep 0.25

while [ $b == 0 ]
do
echo "Holding"
b=$(gpio read 5)



done
fi
done

