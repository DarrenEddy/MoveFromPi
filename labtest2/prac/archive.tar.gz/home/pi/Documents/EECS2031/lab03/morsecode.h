void init_morse(void);
void send_dot(void);
void send_dash(void);
void wait_letter(void);
void wait_word(void);
void wait_dot(void);
void play_buzzer(int msec);
char *char2morse(char c);

