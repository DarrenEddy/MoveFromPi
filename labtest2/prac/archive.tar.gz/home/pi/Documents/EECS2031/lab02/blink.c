#include <wiringPi.h>
int main (int argc, char *argv[])
{
 wiringPiSetup () ;
 pinMode (0, OUTPUT) ;
 for (;;)
 {
 digitalWrite (0, HIGH) ; delay (100) ;
 digitalWrite (0, LOW) ; delay (1000) ;
 }
 return 0 ;
}
