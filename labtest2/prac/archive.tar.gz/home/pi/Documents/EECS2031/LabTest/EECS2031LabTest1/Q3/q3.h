void setTriple(float a, float b, float c, float *x, float *y, float*z);
void addTriple(float a, float b, float c, float *x, float *y, float*z);
