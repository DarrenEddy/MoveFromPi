#!/bin/bash
while test true
do

i=$(shuf -i 0-15 -n 1)

./setbits.sh $i

sleep 0.25

done




