# include <stdio.h>
# include "formula.h"

int main(int argc, char *argv[])
{
printf("if x = %d and n = %d then x^n/n! = %f",1,2, formula(1,2));
printf("if x = %d and n = %d then x^n/n! = %f",4,5, formula(4,5));
printf("if x = %d and n = %d then x^n/n! = %f",19,44, formula(19,44));

return 0;
}
